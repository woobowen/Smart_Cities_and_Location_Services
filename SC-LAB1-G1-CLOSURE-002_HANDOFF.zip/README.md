# Goal1 第二轮审核交接包

首先阅读 GPT_SECOND_REVIEW_ROUND2.md，然后将 SC-LAB1-G1-CLOSURE-002_CODEX_PROMPT.txt 发给 Codex。

- probes/results.json 是GPT本次离线执行的实际结果。
- probes/pilot_independent.json 是相同原始JSON字节的七条pilot独立复算。
- probes/verify_round2_findings.py 可用 --repo 指向目标仓库复现。仅构造输入，不调用模型、不写仓库数据。
- source_snapshot 只用于展示/复现已审核源码，不要覆盖仓库；四个文件逐个核对 Git blob，见 source_manifest.json。
- 后续代码接口变化时应传入真正独立的参考/合同适配测试，不删除原错误样例。
- D1/D2没有新确认时，提示词只运行离线定向修复，不新增LIVE，不进入Goal2/3。

本包不是老师Submission Package，不包含数据副本、论文全文、认证文件或字体。
