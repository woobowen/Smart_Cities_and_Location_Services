"""New review-context tests, executed against hash-verified remote sync_sources.py.
All writes are confined to disposable fixtures; the user's repository is untouched.
"""
from pathlib import Path, PurePosixPath
import importlib.util, json, hashlib, tempfile, zipfile, shutil
from unittest.mock import patch

OUT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('remote_sync',OUT/'remote_code/sync_sources.py')
s=importlib.util.module_from_spec(spec); spec.loader.exec_module(s)
records=[]

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap(root):
 return {p.relative_to(root).as_posix():(digest(p),p.stat().st_mtime_ns)
         for p in root.rglob('*') if p.is_file() and not p.is_symlink() and '.sync-transaction-' not in p.as_posix()}
def setup(root):
 (root/s.INTERNAL_PATH).mkdir(parents=True);(root/s.BUNDLE_PATH).mkdir(parents=True);(root/'active').mkdir()
 shutil.copyfile('/mnt/data/publication-plots.zip',root/'active/publication-plots.zip')
 with zipfile.ZipFile('/mnt/data/publication-plots.zip') as z:
  for i in z.infolist():
   p=PurePosixPath(i.filename)
   if i.is_dir() or '__MACOSX' in p.parts or p.name=='.DS_Store':continue
   rel=PurePosixPath(*p.parts[1:]); dst=root/'tools/skills/publication-plots'/rel
   dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(z.read(i))
 (root/'active/a.md').write_text('accepted alpha\n');(root/'active/b.md').write_text('accepted beta\n')
 rows=[]
 for name in ['a.md','b.md','publication-plots.zip']:
  rows.append(dict(canonical_name=name,active_path='active/'+name,project_source=True,semantic_role='test_fixture',scope='review only',version='1',sha256=digest(root/'active'/name),pair_id=None,approval_scope='review fixture',supersedes=None))
 doc=dict(schema_version=1,approval='review_fixture',revision_date='2026-10-03',sources=rows)
 (root/s.DECLARATION_PATH).write_text(json.dumps(doc))
 s.sync(root)
 return doc

def save_doc(root,doc): (root/s.DECLARATION_PATH).write_text(json.dumps(doc))
def rejects(root,fn=s.sync):
 before=snap(root)
 try:fn(root)
 except (ValueError,RuntimeError,OSError):pass
 else:raise AssertionError('Expected refusal')
 assert snap(root)==before,'Failure mutated protected fixture files'

def test_ok(root,doc):assert len(s.verify_bundle(root))==3;s.verify_manifest(root,s.source_rows(root))
def test_readonly(root,doc):
 before=snap(root);assert s.difference_plan(root)['safe_to_sync'];s.verify_bundle(root);s.verify_manifest(root,s.source_rows(root));assert snap(root)==before

def test_idempotent(root,doc):
 before=snap(root);r1=s.sync(root);r2=s.sync(root);assert r1['updated']==r2['updated']==[];assert snap(root)==before

def test_dynamic(root,doc):
 (root/'active/c.md').write_text('extra approved fixture')
 row=dict(doc['sources'][0],canonical_name='c.md',active_path='active/c.md',sha256=digest(root/'active/c.md'))
 doc['sources'].append(row);save_doc(root,doc);r=s.sync(root);assert r['file_count']==4;assert len(s.verify_bundle(root))==4

def test_missing(root,doc):(root/'active/a.md').unlink();rejects(root)
def test_bad_hash(root,doc):(root/'active/a.md').write_text('unapproved change');rejects(root)
def test_unknown(root,doc):(root/s.BUNDLE_PATH/'unknown.md').write_text('keep me');rejects(root)
def test_wrong_member(root,doc):(root/s.BUNDLE_PATH/'a.md').rename(root/s.BUNDLE_PATH/'wrong.md');rejects(root)
def test_file_link(root,doc):
 p=root/s.BUNDLE_PATH/'a.md';p.unlink();p.symlink_to(root/'active/a.md');rejects(root)
def test_parent_link(root,doc):
 (root/'active').rename(root/'real_active');(root/'active').symlink_to(root/'real_active',target_is_directory=True);rejects(root)
def test_self_reference(root,doc):doc['sources'][0]['active_path']=str(s.BUNDLE_PATH/'a.md');save_doc(root,doc);rejects(root)
def test_escape(root,doc):doc['sources'][0]['active_path']='../outside.md';save_doc(root,doc);rejects(root)
def test_restore_missing_target(root,doc):
 p=root/s.BUNDLE_PATH/'a.md';p.unlink();assert 'a.md' in s.difference_plan(root)['add'];s.sync(root);assert p.read_bytes()==(root/'active/a.md').read_bytes()
def test_directory_in_bundle(root,doc):(root/s.BUNDLE_PATH/'unrecognized').mkdir();rejects(root)
def test_stale_metadata(root,doc):
 p=root/s.INTERNAL_PATH/'SOURCE_MANIFEST.md';p.write_text('stale');before=snap(root)
 try:s.verify_manifest(root,s.source_rows(root))
 except ValueError:pass
 else:raise AssertionError('Expected stale metadata refusal')
 assert snap(root)==before
 s.sync(root);s.verify_manifest(root,s.source_rows(root))
def test_rollback(root,doc):
 for name in ['a.md','b.md']:(root/s.BUNDLE_PATH/name).write_text('outdated '+name)
 before=snap(root);orig=s.os.replace;calls=[0]
 def failing(a,b):
  calls[0]+=1
  if calls[0]==2:raise OSError('injected second replacement failure')
  return orig(a,b)
 with patch.object(s.os,'replace',side_effect=failing):
  try:s.sync(root)
  except RuntimeError:pass
  else:raise AssertionError('Expected injected failure')
 assert snap(root)==before
 recovery=list((root/s.INTERNAL_PATH).glob('.sync-transaction-*/recovery.json'))
 assert len(recovery)==1 and json.loads(recovery[0].read_text())['state']=='ROLLED_BACK'

tests=[v for k,v in list(globals().items()) if k.startswith('test_')]
for test in tests:
 with tempfile.TemporaryDirectory(prefix='sc-review-fixture-') as tmp:
  root=Path(tmp);doc=setup(root)
  try:test(root,doc);records.append(dict(test=test.__name__,status='PASS'))
  except Exception as exc:records.append(dict(test=test.__name__,status='FAIL',error=repr(exc)))
result={'implementation_git_blob':'6ee634db93f1860e66c26df735aa810f09c949f4','test_author':'current GPT review context','isolated_fixture_only':True,'cases':records,'passed':sum(r['status']=='PASS' for r in records),'failed':sum(r['status']=='FAIL' for r in records)}
(OUT/'independent_sync_test_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
