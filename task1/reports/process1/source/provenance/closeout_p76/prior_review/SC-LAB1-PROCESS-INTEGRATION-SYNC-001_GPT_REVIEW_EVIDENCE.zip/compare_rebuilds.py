from pathlib import Path
import fitz, json, hashlib, numpy as np
R=Path('/mnt/data/sc_review_9d9139');paths={'approved':Path('/mnt/data/Process_Report_Revised.pdf'),'A':R/'route_A/Process_Report_Revised.pdf','B':R/'route_B/Process_Report_Revised.pdf'}
docs={k:fitz.open(p) for k,p in paths.items()};summary={'paths':{k:str(p) for k,p in paths.items()},'pdf_sha256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()},'renderer':str(fitz.VersionBind),'pages':[]}
for i in range(len(docs['approved'])):
 row={'page':i+1};ref=docs['approved'][i];rp=ref.get_pixmap(dpi=200,alpha=False);ra=np.frombuffer(rp.samples,dtype=np.uint8).reshape(rp.height,rp.width,3)
 for k in ['A','B']:
  p=docs[k][i];pix=p.get_pixmap(dpi=200,alpha=False);x=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,3)
  delta=np.abs(x.astype(np.int16)-ra.astype(np.int16))
  row[k]={'page_size_equal':p.rect==ref.rect,'text_exact':p.get_text()==ref.get_text(),'pixel_exact':bool(np.array_equal(ra,x)),'max_channel_delta':int(delta.max()),'changed_pixels':int(np.any(delta!=0,axis=2).sum())}
 summary['pages'].append(row)
summary['totals']={k:{key:sum(p[k][key] for p in summary['pages']) for key in ['page_size_equal','text_exact','pixel_exact']} for k in ['A','B']}
# Independently check exact persistence of every specified generated artifact.
selected=['main.tex','chapters/pages.tex','provenance/page_map.json','provenance/crop_map.json','provenance/arrow_map.json','provenance/input_images.json']
for p in (R/'approved_source'/'assets/crops').glob('*'):selected.append(p.relative_to(R/'approved_source').as_posix())
summary['generated_content_checks']={rel:(R/'approved_source'/rel).read_bytes()==(R/'route_B'/rel).read_bytes() for rel in selected}
summary['generated_content_all_exact']=all(summary['generated_content_checks'].values())
(R/'independent_build_comparison.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k not in ['pages','generated_content_checks']},ensure_ascii=False,indent=2))
print('differences',[p for p in summary['pages'] if not(p['A']['pixel_exact'] and p['B']['pixel_exact'])])
