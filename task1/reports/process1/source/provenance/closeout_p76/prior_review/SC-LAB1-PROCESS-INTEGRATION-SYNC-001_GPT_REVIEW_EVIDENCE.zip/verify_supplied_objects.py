from pathlib import Path, PurePosixPath
import hashlib,json,zipfile,stat
BASE=Path('/mnt/data'); OUT=BASE/'sc_review_9d9139'
remote_blobs={
'AGENTS.md':'f8c7d67fd09919b9cae98d894bf9032662b8f517',
'Experiment_Report_P2_Exact.pdf':'69129c159c3a3a74a649a46c7e1f039026c3c485',
'Experiment_Report_吴博闻_10245102410.pdf':'700d4d2df2f7c74aa0bb6f4a7aed79d0b6ac1ad5',
'Experiment_Report_完整重构_源文件.zip':'ba5b10d04956136ad59722e4a20c453f32e7ce00',
'Process_Report_Revised.pdf':'78cd6d550c9126257baa619ae3e44f9d18da84e5',
'Process_Report_Revised_LaTeX_Source.zip':'1706b14902c007b5dec89b92cc01e0aa2382a270',
'SMART_CITIES_REPORT_WRITING_GUIDE.md':'fe16596b72c6b3278b41553877f92b07cf669a6d',
'SMART_CITIES_RESEARCH_PROTOCOL.md':'5744f5a17e385eddca4fcd3048b6039042eacf0a',
'SMART_CITIES_VISUAL_SYSTEM.md':'ea02a42f5c5776d1206b2c45fe5a048607636b2e',
'WORKFLOW_INTERACTION_EVIDENCE_PROTOCOL.md':'103156a6399c96a8dce63ab2b2367a87e38932ad',
'publication-plots.zip':'aa5a4abee50860086ab1e6d9323ea1e61582d466',
'任务3_LLM辅助评估清洗.ipynb':'1107126898a97bee75ebe15fa05163810c5d9344',
'作业.zip':'3e41b61874176f6cc02d47c989620c7ea1147307',
'作业1轨迹数据预处理.ipynb':'a17e239ed5bc540762f18210e1ddbbf067e0819b',
'实验课1.pptx':'73d98c314d062ce1d917c15f41804fb0dcee493c'}
def git_hash(kind,data):return hashlib.sha1(kind.encode()+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()
def tree_hash(tree):
    chunks=[]
    for name,v in sorted(tree.items(),key=lambda x:(x[0]+'/' if isinstance(x[1],dict) else x[0]).encode()):
        if isinstance(v,dict):mode,sha='40000',tree_hash(v)
        else:mode,sha='100644',git_hash('blob',v)
        chunks.append(mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(sha))
    return git_hash('tree',b''.join(chunks))
baseline=json.loads((BASE/'SC-LAB1-PROCESS-INTEGRATION-SYNC-001_INPUT_BASELINE.json').read_text())
rows=[];flat={}
for r in baseline['files']:
    data=(BASE/r['observed_attachment_name']).read_bytes(); name=r['canonical_name']
    sha256=hashlib.sha256(data).hexdigest(); blob=git_hash('blob',data)
    rows.append(dict(name=name,bytes=len(data),sha256=sha256,approved_sha256_matches=sha256==r['sha256'],git_blob=blob,remote_blob=remote_blobs[name],remote_git_blob_matches=blob==remote_blobs[name]))
    flat[name]=data
actual_release_tree=tree_hash(flat)
assert all(r['approved_sha256_matches'] and r['remote_git_blob_matches'] for r in rows)
assert actual_release_tree=='1b43421b57598d25cf625c8da9602c356cce2f4b'
z=zipfile.ZipFile(BASE/'Process_Report_Revised_LaTeX_Source.zip'); prefix='Process_Report_Revised_Source/'
unsafe=[];tree={}; seen=set();target=OUT/'approved_source'
for i in z.infolist():
    p=PurePosixPath(i.filename)
    if p.is_absolute() or '..' in p.parts or i.filename in seen or stat.S_ISLNK(i.external_attr>>16): unsafe.append(i.filename)
    seen.add(i.filename)
    assert i.filename.startswith(prefix)
    rel=i.filename[len(prefix):]; b=z.read(i);node=tree
    for part in PurePosixPath(rel).parts[:-1]:node=node.setdefault(part,{})
    node[PurePosixPath(rel).name]=b
    dst=target/rel; dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
source_tree_644=tree_hash(tree)
chunks=[]
for name,v in sorted(tree.items(),key=lambda x:(x[0]+'/' if isinstance(x[1],dict) else x[0]).encode()):
    mode='40000' if isinstance(v,dict) else ('100755' if name=='compile.sh' else '100644')
    h=tree_hash(v) if isinstance(v,dict) else git_hash('blob',v)
    chunks.append(mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(h))
source_tree=git_hash('tree',b''.join(chunks))
result={'remote_commit':'9d91392289b31a4afa5c94cfd3869da9f021b4ad','provenance':'Live GitHub tree entries copied from API results, independently hashed mounted user originals; no binary network download claimed.','files':rows,'release_tree':actual_release_tree,'release_tree_matches_remote':True,'source_members':len(seen),'source_crc':z.testzip(),'source_unsafe_members':unsafe,'source_tree_all_644':source_tree_644,'verified_mode_adaptation':'compile.sh executable in Git; bytes unchanged','source_tree':source_tree,'remote_source_tree':'f32af8ab769fcacf216a2ba24fe61926206ab381','source_tree_matches_remote':source_tree=='f32af8ab769fcacf216a2ba24fe61926206ab381','zip_pdf_pair':z.read(prefix+'Process_Report_Revised.pdf')==(BASE/'Process_Report_Revised.pdf').read_bytes()}
(OUT/'supplied_object_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='files'},ensure_ascii=False,indent=2))
