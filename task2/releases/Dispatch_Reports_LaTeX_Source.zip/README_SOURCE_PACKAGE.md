# Dispatch reports: paired editable sources

Extract while preserving the relative `task2/` and `templates/` directories.
Run from this extracted root with Python 3 and XeLaTeX/latexmk, Poppler tools,
DejaVu Serif/Sans and Noto Serif/Sans/Mono CJK SC installed:

    python3 task2/scripts/build_reports.py

Alternatively run `latexmk -g -xelatex -outdir=build main.tex` inside each
`task2/reports/{experiment,process}` directory. The included PDFs are the actual
paired delivery PDFs, not a replacement for rebuilding their source.

This is a report-compilation source package. It includes editable LaTeX,
generated tables, vector figures, editable draw.io nodes/edges, and the exact
common P2 source copied for distribution. In the repository that common file
remains the sole editable color source. No font binaries or Foursquare records
are distributed. Scientific plots can be regenerated separately from the public
repository scripts/aggregate inputs; experiment recomputation uses the author's
verified public download and fixed input hashes documented in the repository.

Process Report is a text/technical-material handoff. New native ChatGPT UI
screenshots, presentation specification and Evidence Master Lock remain external.
Compilation does not establish data recomputation or visual acceptance.
