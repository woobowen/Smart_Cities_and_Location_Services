# Design System distribution manifest

- version = v2.1
- Experiment Report = LOCKED
- Process Report = LOCKED
- P2 Cloud Sorbet Exact = LOCKED
- Compilation engine = XeLaTeX
- Demo assets are synthetic/template material, not experimental results or real interaction evidence.

v2.1 is a technical repair release of the installed v2 specification: corrected demo-asset paths, a common P2 color source, LaTeX warning fixes, and installed Skill references. It introduces no visual redesign.

The installed publication-plots Skill is distributed separately under releases/skills/publication-plots.zip. It is not needed to compile these template previews.

From each report directory, run:

```bash
latexmk -xelatex -interaction=nonstopmode -file-line-error -halt-on-error -outdir=build experiment_report_template.tex
latexmk -xelatex -interaction=nonstopmode -file-line-error -halt-on-error -outdir=build process_report_template.tex
```

The packaged previews are installed visual references. Fresh build PDFs are generated from the packaged sources during release verification.
