# Smart Cities Design System v2.1

Status: LOCKED

## Locked identity

- P2 · Cloud Sorbet Exact
- XeLaTeX
- Experiment Report:
  - A-style Modern Academic Minimal cover
  - B-style Visual Research body
- Process Report:
  - Workflow Construction
  - Experiment Decision Process
  - real multi-page Human–AI evidence
  - Contact Sheet
  - raw + annotated screenshots
- Process Diagram Language:
  - Editorial Decision Board
  - Human Reasoning → Evidence → Decision
  - Horizontal Candidate Decision Tree

## v2.1 synchronization

This package includes the current installed sources after:
- asset-path repair;
- shared P2 single-source repair;
- LaTeX warning repair;
- installed publication-plots path synchronization;
- Process Report scope synchronization:
  Workflow Construction + Experiment Decision Process.

Demo assets are template-only material and are not experimental evidence.

Compile formal templates with XeLaTeX / latexmk.
